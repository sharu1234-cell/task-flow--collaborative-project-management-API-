# Install Node.js and npm - Quick Guide

## The Error
`npm : The term 'npm' is not recognized` means Node.js/npm is not installed or not in your PATH.

## Solution 1: Install Node.js (Recommended)

### For Windows:

1. **Download Node.js:**
   - Go to: https://nodejs.org/
   - Download the **LTS version** (recommended)
   - Choose Windows Installer (.msi)

2. **Install:**
   - Run the downloaded .msi file
   - Click "Next" through the installation
   - **IMPORTANT:** Check "Add to PATH" option (should be checked by default)
   - Complete the installation

3. **Restart Terminal:**
   - Close your current terminal/PowerShell
   - Open a NEW terminal window
   - Verify installation:
     ```bash
     node --version
     npm --version
     ```

4. **If still not working:**
   - Restart your computer
   - Or manually add to PATH (see below)

## Solution 2: Manual PATH Configuration

If Node.js is installed but not recognized:

1. **Find Node.js installation:**
   - Usually at: `C:\Program Files\nodejs\`
   - Or: `C:\Users\YourName\AppData\Roaming\npm`

2. **Add to PATH:**
   - Press `Win + R`
   - Type: `sysdm.cpl` and press Enter
   - Go to "Advanced" tab
   - Click "Environment Variables"
   - Under "System variables", find "Path"
   - Click "Edit"
   - Click "New"
   - Add: `C:\Program Files\nodejs\`
   - Click OK on all windows
   - Restart terminal

## Solution 3: Use Chocolatey (Windows Package Manager)

If you have Chocolatey installed:

```powershell
choco install nodejs
```

## Solution 4: Use Winget (Windows 11)

```powershell
winget install OpenJS.NodeJS.LTS
```

## Verify Installation

After installation, open a NEW terminal and run:

```bash
node --version
npm --version
```

You should see version numbers like:
- `v18.17.0` (or similar)
- `9.6.7` (or similar)

## Then Install Project Dependencies

Once npm is working:

```bash
cd "C:\Users\SHARVANI\BK Priject2"
npm install
```

## Still Having Issues?

1. Make sure you're using a NEW terminal window after installation
2. Try restarting your computer
3. Check if Node.js is installed: Look for "Node.js" in Start Menu
4. Try running from Node.js command prompt (if available)



