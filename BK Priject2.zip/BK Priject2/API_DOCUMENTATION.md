# TaskFlow API Documentation

## Base URL
```
http://localhost:3000/api/v1
```

## Authentication

Most endpoints require authentication. Include the JWT token in the Authorization header:
```
Authorization: Bearer <your-token>
```

## Endpoints

### Authentication

#### Register User
```http
POST /auth/register
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "name": "John Doe",
  "role": "member"
}
```

**Response:**
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "user": {
      "id": 1,
      "email": "user@example.com",
      "name": "John Doe",
      "role": "member"
    },
    "token": "jwt-token-here"
  }
}
```

#### Login
```http
POST /auth/login
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

#### Get Current User
```http
GET /auth/me
```

---

### Projects

#### Get All Projects
```http
GET /projects?page=1&limit=10&status=active&search=keyword
```

**Query Parameters:**
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10, max: 100)
- `status` - Filter by status
- `created_by` - Filter by creator ID
- `parent_id` - Filter by parent project ID (use `null` for root projects)
- `search` - Search in name and description

#### Get Project by ID
```http
GET /projects/:id
```

#### Create Project
```http
POST /projects
```

**Request Body:**
```json
{
  "name": "Project Name",
  "description": "Project description",
  "start_date": "2024-01-01",
  "end_date": "2024-12-31",
  "status": "planning",
  "parent_id": null
}
```

#### Update Project
```http
PUT /projects/:id
```

#### Delete Project
```http
DELETE /projects/:id
```
*Requires admin or manager role*

#### Get Project Hierarchy
```http
GET /projects/:id/hierarchy
```

---

### Tasks

#### Get All Tasks
```http
GET /tasks?project_id=1&status=todo&priority=high&assignee_id=3
```

**Query Parameters:**
- `project_id` - Filter by project
- `status` - Filter by status
- `priority` - Filter by priority
- `assignee_id` - Filter by assignee
- `created_by` - Filter by creator
- `search` - Search in title and description

#### Get Task by ID
```http
GET /tasks/:id
```

#### Create Task
```http
POST /tasks
```

**Request Body:**
```json
{
  "title": "Task Title",
  "description": "Task description",
  "project_id": 1,
  "priority": "high",
  "status": "todo",
  "due_date": "2024-12-31T23:59:59",
  "estimated_hours": 8.0
}
```

#### Update Task
```http
PUT /tasks/:id
```

#### Delete Task
```http
DELETE /tasks/:id
```

#### Assign User to Task
```http
POST /tasks/:id/assignees
```

**Request Body:**
```json
{
  "user_id": 3
}
```

#### Remove Assignee
```http
DELETE /tasks/:id/assignees/:userId
```

#### Add Task Dependency
```http
POST /tasks/:id/dependencies
```

**Request Body:**
```json
{
  "depends_on_task_id": 2
}
```

#### Remove Dependency
```http
DELETE /tasks/:id/dependencies/:dependsOnId
```

---

### Teams

#### Get All Teams
```http
GET /teams?project_id=1&search=keyword
```

#### Get Team by ID
```http
GET /teams/:id
```

#### Create Team
```http
POST /teams
```

**Request Body:**
```json
{
  "name": "Team Name",
  "description": "Team description",
  "project_id": 1
}
```

#### Add Member to Team
```http
POST /teams/:id/members
```

**Request Body:**
```json
{
  "user_id": 3,
  "role": "member"
}
```

#### Remove Member
```http
DELETE /teams/:id/members/:userId
```

---

### Comments

#### Get Comments
```http
GET /comments?task_id=1&project_id=1&page=1&limit=10
```
*Requires either task_id or project_id*

#### Create Comment
```http
POST /comments
```

**Request Body:**
```json
{
  "content": "Comment text",
  "task_id": 1,
  "parent_id": null
}
```

#### Update Comment
```http
PUT /comments/:id
```

#### Delete Comment
```http
DELETE /comments/:id
```

---

### Files

#### Upload File
```http
POST /files/upload
Content-Type: multipart/form-data
```

**Form Data:**
- `file` - File to upload
- `task_id` - Optional task ID
- `project_id` - Optional project ID

#### Get Files
```http
GET /files?task_id=1&project_id=1
```

#### Download File
```http
GET /files/:id/download
```

#### Delete File
```http
DELETE /files/:id
```

---

### Activities

#### Get Activity Feed
```http
GET /activities?project_id=1&user_id=3&type=task_created&page=1&limit=20
```

---

### Notifications

#### Get Notifications
```http
GET /notifications?read=false&page=1&limit=20
```

#### Mark Notification as Read
```http
PUT /notifications/:id/read
```

#### Mark All as Read
```http
PUT /notifications/read-all
```

---

### Analytics

#### Get Project Progress
```http
GET /analytics/projects/:id/progress
```

**Response:**
```json
{
  "success": true,
  "data": {
    "progress": {
      "total_tasks": 10,
      "completed_tasks": 5,
      "in_progress_tasks": 3,
      "todo_tasks": 2,
      "blocked_tasks": 0,
      "total_estimated_hours": 80.0,
      "progress_percentage": 50
    }
  }
}
```

#### Get Team Productivity
```http
GET /analytics/teams/:id/productivity
```

#### Get Burndown Chart Data
```http
GET /analytics/projects/:id/burndown?days=30
```

#### Generate Custom Report
```http
GET /analytics/reports?project_id=1&start_date=2024-01-01&end_date=2024-12-31&status=active
```

---

## Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request
- `401` - Unauthorized
- `403` - Forbidden
- `404` - Not Found
- `409` - Conflict
- `500` - Internal Server Error

## Error Response Format

```json
{
  "success": false,
  "message": "Error message",
  "errors": [
    {
      "field": "email",
      "message": "Valid email required"
    }
  ]
}
```

## Pagination Response Format

```json
{
  "success": true,
  "data": {
    "items": [...],
    "meta": {
      "currentPage": 1,
      "totalPages": 5,
      "totalItems": 50,
      "itemsPerPage": 10,
      "hasNextPage": true,
      "hasPreviousPage": false
    }
  }
}
```



