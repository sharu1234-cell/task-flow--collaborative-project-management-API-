# TaskFlow Setup Guide

## Quick Start

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Configure Environment**
   ```bash
   cp .env.example .env
   ```
   Edit `.env` with your database credentials.

3. **Setup Database**
   ```bash
   npm run migrate
   ```

4. **Start Server**
   ```bash
   npm start
   ```

## Detailed Setup

### Step 1: Prerequisites
- Node.js v14+
- MySQL 5.7+
- npm or yarn

### Step 2: Database Setup

1. Create MySQL database (optional - migration script creates it):
   ```sql
   CREATE DATABASE taskflow_db;
   ```

2. Update `.env` file:
   ```env
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=your_password
   DB_NAME=taskflow_db
   DB_PORT=3306
   JWT_SECRET=your-secret-key-here
   ```

3. Run migrations:
   ```bash
   npm run migrate
   ```

   This will:
   - Create database schema
   - Insert sample data

### Step 3: Install Dependencies
```bash
npm install
```

### Step 4: Start Development Server
```bash
npm run dev
```

Server runs on `http://localhost:3000`

### Step 5: Test the API

1. **Register a user:**
   ```bash
   curl -X POST http://localhost:3000/api/v1/auth/register \
     -H "Content-Type: application/json" \
     -d '{"email":"test@example.com","password":"password123","name":"Test User"}'
   ```

2. **Login:**
   ```bash
   curl -X POST http://localhost:3000/api/v1/auth/login \
     -H "Content-Type: application/json" \
     -d '{"email":"admin@taskflow.com","password":"password123"}'
   ```

3. **Use the token in subsequent requests:**
   ```bash
   curl http://localhost:3000/api/v1/projects \
     -H "Authorization: Bearer YOUR_TOKEN_HERE"
   ```

## Sample Users

After running migrations, you can login with:
- Email: `admin@taskflow.com` / Password: `password123`
- Email: `manager@taskflow.com` / Password: `password123`
- Email: `john@taskflow.com` / Password: `password123`

## Testing

Run tests:
```bash
npm test
```

Run tests with coverage:
```bash
npm test -- --coverage
```

## Postman Collection

Import `postman_collection.json` into Postman:
1. Open Postman
2. Click Import
3. Select `postman_collection.json`
4. Set environment variable `baseUrl` to `http://localhost:3000`
5. Login first to get token, then set `token` variable

## Troubleshooting

**Port 3000 already in use:**
- Change PORT in `.env` file

**Database connection error:**
- Verify MySQL is running
- Check credentials in `.env`
- Ensure database exists

**Module not found:**
- Run `npm install` again

**Password hash issues:**
- Use `node migrations/generatePasswordHash.js` to generate proper hashes
- Or use `node migrations/seedDataWithHash.js` for automatic seeding



