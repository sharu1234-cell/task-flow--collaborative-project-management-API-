const express = require('express');
const { body } = require('express-validator');
const { authenticate, authorize } = require('../middleware/auth');
const { authLimiter } = require('../middleware/rateLimiter');
const { validate } = require('../middleware/validator');
const { successResponse, errorResponse } = require('../utils/response');
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const logger = require('../config/logger');

const router = express.Router();

// Register
router.post('/register',
  authLimiter,
  [
    body('email').isEmail().withMessage('Valid email required'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('name').trim().notEmpty().withMessage('Name is required'),
    body('role').optional().isIn(['admin', 'manager', 'member']).withMessage('Invalid role')
  ],
  validate,
  async (req, res) => {
    try {
      const { email, password, name, role } = req.body;

      // Check if user exists
      const existingUser = await User.findByEmail(email);
      if (existingUser) {
        return errorResponse(res, 'User already exists', 409);
      }

      // Create user
      const user = await User.create({ email, password, name, role });

      // Generate token
      const token = jwt.sign(
        { userId: user.id, email: user.email },
        process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-in-production',
        { expiresIn: process.env.JWT_EXPIRE || '7d' }
      );

      successResponse(res, {
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role
        },
        token
      }, 'User registered successfully', 201);
    } catch (error) {
      logger.error('Registration error:', error);
      errorResponse(res, 'Registration failed', 500);
    }
  }
);

// Login
router.post('/login',
  authLimiter,
  [
    body('email').isEmail().withMessage('Valid email required'),
    body('password').notEmpty().withMessage('Password is required')
  ],
  validate,
  async (req, res) => {
    try {
      const { email, password } = req.body;

      // Find user
      const user = await User.findByEmail(email);
      if (!user) {
        return errorResponse(res, 'Invalid credentials', 401);
      }

      // Check password
      const isValidPassword = await User.verifyPassword(password, user.password);
      if (!isValidPassword) {
        return errorResponse(res, 'Invalid credentials', 401);
      }

      // Check if user is active
      if (user.status !== 'active') {
        return errorResponse(res, 'Account is inactive', 403);
      }

      // Generate token
      const token = jwt.sign(
        { userId: user.id, email: user.email },
        process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-in-production',
        { expiresIn: process.env.JWT_EXPIRE || '7d' }
      );

      successResponse(res, {
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role
        },
        token
      }, 'Login successful');
    } catch (error) {
      logger.error('Login error:', error);
      errorResponse(res, 'Login failed', 500);
    }
  }
);

// Get current user
router.get('/me', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    successResponse(res, { user }, 'User retrieved successfully');
  } catch (error) {
    logger.error('Get user error:', error);
    errorResponse(res, 'Failed to retrieve user', 500);
  }
});

module.exports = router;



