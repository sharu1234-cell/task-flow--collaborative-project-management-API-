const express = require('express');
const { authenticate } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');
const { validate, paginationRules } = require('../middleware/validator');
const { successResponse, errorResponse } = require('../utils/response');
const { getPaginationParams, getPaginationMeta } = require('../utils/pagination');
const { promisePool } = require('../config/database');
const logger = require('../config/logger');

const router = express.Router();

router.use(authenticate);
router.use(apiLimiter);

// Get activity feed
router.get('/',
  paginationRules,
  validate,
  async (req, res) => {
    try {
      const pagination = getPaginationParams(req);
      const { project_id, user_id, type } = req.query;

      let query = `SELECT a.*, 
                          u.name as user_name, u.email as user_email,
                          p.name as project_name
                   FROM activities a
                   JOIN users u ON a.user_id = u.id
                   LEFT JOIN projects p ON a.project_id = p.id
                   WHERE 1=1`;
      const params = [];

      if (project_id) {
        query += ' AND a.project_id = ?';
        params.push(project_id);
      }
      if (user_id) {
        query += ' AND a.user_id = ?';
        params.push(user_id);
      }
      if (type) {
        query += ' AND a.type = ?';
        params.push(type);
      }

      query += ' ORDER BY a.created_at DESC LIMIT ? OFFSET ?';
      params.push(pagination.limit, pagination.offset);

      const [activities] = await promisePool.execute(query, params);

      // Get total count
      let countQuery = 'SELECT COUNT(*) as total FROM activities WHERE 1=1';
      const countParams = [];
      if (project_id) {
        countQuery += ' AND project_id = ?';
        countParams.push(project_id);
      }
      if (user_id) {
        countQuery += ' AND user_id = ?';
        countParams.push(user_id);
      }
      if (type) {
        countQuery += ' AND type = ?';
        countParams.push(type);
      }

      const [countResult] = await promisePool.execute(countQuery, countParams);
      const total = countResult[0].total;
      const meta = getPaginationMeta(pagination.page, pagination.limit, total);

      successResponse(res, { activities, meta }, 'Activities retrieved successfully');
    } catch (error) {
      logger.error('Get activities error:', error);
      errorResponse(res, 'Failed to retrieve activities', 500);
    }
  }
);

module.exports = router;



