const express = require('express');
const { authenticate } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');
const { validate, paginationRules, idParamRule } = require('../middleware/validator');
const { successResponse, errorResponse } = require('../utils/response');
const { getPaginationParams, getPaginationMeta } = require('../utils/pagination');
const { promisePool } = require('../config/database');
const logger = require('../config/logger');

const router = express.Router();

router.use(authenticate);
router.use(apiLimiter);

// Get user notifications
router.get('/',
  paginationRules,
  validate,
  async (req, res) => {
    try {
      const pagination = getPaginationParams(req);
      const { read } = req.query;

      let query = `SELECT * FROM notifications 
                   WHERE user_id = ?`;
      const params = [req.user.id];

      if (read !== undefined) {
        query += ' AND is_read = ?';
        params.push(read === 'true' ? 1 : 0);
      }

      query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
      params.push(pagination.limit, pagination.offset);

      const [notifications] = await promisePool.execute(query, params);

      // Get total count
      let countQuery = 'SELECT COUNT(*) as total FROM notifications WHERE user_id = ?';
      const countParams = [req.user.id];
      if (read !== undefined) {
        countQuery += ' AND is_read = ?';
        countParams.push(read === 'true' ? 1 : 0);
      }

      const [countResult] = await promisePool.execute(countQuery, countParams);
      const total = countResult[0].total;
      const meta = getPaginationMeta(pagination.page, pagination.limit, total);

      successResponse(res, { notifications, meta }, 'Notifications retrieved successfully');
    } catch (error) {
      logger.error('Get notifications error:', error);
      errorResponse(res, 'Failed to retrieve notifications', 500);
    }
  }
);

// Mark notification as read
router.put('/:id/read',
  idParamRule,
  validate,
  async (req, res) => {
    try {
      await promisePool.execute(
        'UPDATE notifications SET is_read = 1, read_at = NOW() WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.id]
      );

      successResponse(res, null, 'Notification marked as read');
    } catch (error) {
      logger.error('Mark notification read error:', error);
      errorResponse(res, 'Failed to mark notification as read', 500);
    }
  }
);

// Mark all notifications as read
router.put('/read-all',
  async (req, res) => {
    try {
      await promisePool.execute(
        'UPDATE notifications SET is_read = 1, read_at = NOW() WHERE user_id = ? AND is_read = 0',
        [req.user.id]
      );

      successResponse(res, null, 'All notifications marked as read');
    } catch (error) {
      logger.error('Mark all notifications read error:', error);
      errorResponse(res, 'Failed to mark all notifications as read', 500);
    }
  }
);

module.exports = router;



