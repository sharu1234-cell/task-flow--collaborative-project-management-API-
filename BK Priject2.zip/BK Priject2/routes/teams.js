const express = require('express');
const { body } = require('express-validator');
const { authenticate, authorize } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');
const { validate, paginationRules, idParamRule } = require('../middleware/validator');
const { successResponse, errorResponse } = require('../utils/response');
const { getPaginationParams, getPaginationMeta } = require('../utils/pagination');
const { promisePool } = require('../config/database');
const logger = require('../config/logger');
const { createActivity } = require('../models/Activity');

const router = express.Router();

router.use(authenticate);
router.use(apiLimiter);

// Get all teams
router.get('/',
  paginationRules,
  validate,
  async (req, res) => {
    try {
      const pagination = getPaginationParams(req);
      const { project_id, search } = req.query;

      let query = `SELECT t.*, 
                          p.name as project_name,
                          (SELECT COUNT(*) FROM team_members WHERE team_id = t.id) as member_count
                   FROM teams t
                   LEFT JOIN projects p ON t.project_id = p.id
                   WHERE 1=1`;
      const params = [];

      if (project_id) {
        query += ' AND t.project_id = ?';
        params.push(project_id);
      }
      if (search) {
        query += ' AND t.name LIKE ?';
        params.push(`%${search}%`);
      }

      query += ' ORDER BY t.created_at DESC LIMIT ? OFFSET ?';
      params.push(pagination.limit, pagination.offset);

      const [teams] = await promisePool.execute(query, params);

      // Get total count
      let countQuery = 'SELECT COUNT(*) as total FROM teams WHERE 1=1';
      const countParams = [];
      if (project_id) {
        countQuery += ' AND project_id = ?';
        countParams.push(project_id);
      }
      if (search) {
        countQuery += ' AND name LIKE ?';
        countParams.push(`%${search}%`);
      }

      const [countResult] = await promisePool.execute(countQuery, countParams);
      const total = countResult[0].total;
      const meta = getPaginationMeta(pagination.page, pagination.limit, total);

      successResponse(res, { teams, meta }, 'Teams retrieved successfully');
    } catch (error) {
      logger.error('Get teams error:', error);
      errorResponse(res, 'Failed to retrieve teams', 500);
    }
  }
);

// Get team by ID
router.get('/:id',
  idParamRule,
  validate,
  async (req, res) => {
    try {
      const [teams] = await promisePool.execute(
        `SELECT t.*, p.name as project_name 
         FROM teams t
         LEFT JOIN projects p ON t.project_id = p.id
         WHERE t.id = ?`,
        [req.params.id]
      );

      if (teams.length === 0) {
        return errorResponse(res, 'Team not found', 404);
      }

      // Get team members
      const [members] = await promisePool.execute(
        `SELECT u.id, u.name, u.email, tm.role, tm.joined_at 
         FROM team_members tm
         JOIN users u ON tm.user_id = u.id
         WHERE tm.team_id = ?`,
        [req.params.id]
      );

      successResponse(res, { 
        team: {
          ...teams[0],
          members
        }
      }, 'Team retrieved successfully');
    } catch (error) {
      logger.error('Get team error:', error);
      errorResponse(res, 'Failed to retrieve team', 500);
    }
  }
);

// Create team
router.post('/',
  [
    body('name').trim().notEmpty().withMessage('Team name is required'),
    body('project_id').isInt({ min: 1 }).withMessage('Valid project ID is required'),
    body('description').optional().trim()
  ],
  validate,
  async (req, res) => {
    try {
      const [result] = await promisePool.execute(
        `INSERT INTO teams (name, project_id, description, created_by, created_at) 
         VALUES (?, ?, ?, ?, NOW())`,
        [req.body.name, req.body.project_id, req.body.description || null, req.user.id]
      );

      const [teams] = await promisePool.execute(
        'SELECT * FROM teams WHERE id = ?',
        [result.insertId]
      );

      // Create activity
      await createActivity({
        project_id: req.body.project_id,
        user_id: req.user.id,
        type: 'team_created',
        description: `Team "${req.body.name}" was created`
      });

      successResponse(res, { team: teams[0] }, 'Team created successfully', 201);
    } catch (error) {
      logger.error('Create team error:', error);
      errorResponse(res, 'Failed to create team', 500);
    }
  }
);

// Add member to team
router.post('/:id/members',
  idParamRule,
  [
    body('user_id').isInt({ min: 1 }).withMessage('Valid user ID is required'),
    body('role').optional().isIn(['lead', 'member', 'contributor']).withMessage('Invalid role')
  ],
  validate,
  async (req, res) => {
    try {
      await promisePool.execute(
        'INSERT IGNORE INTO team_members (team_id, user_id, role, joined_at) VALUES (?, ?, ?, NOW())',
        [req.params.id, req.body.user_id, req.body.role || 'member']
      );

      const [members] = await promisePool.execute(
        `SELECT u.id, u.name, u.email, tm.role, tm.joined_at 
         FROM team_members tm
         JOIN users u ON tm.user_id = u.id
         WHERE tm.team_id = ?`,
        [req.params.id]
      );

      successResponse(res, { members }, 'Member added successfully');
    } catch (error) {
      logger.error('Add member error:', error);
      errorResponse(res, 'Failed to add member', 500);
    }
  }
);

// Remove member from team
router.delete('/:id/members/:userId',
  idParamRule,
  async (req, res) => {
    try {
      await promisePool.execute(
        'DELETE FROM team_members WHERE team_id = ? AND user_id = ?',
        [req.params.id, req.params.userId]
      );
      successResponse(res, null, 'Member removed successfully');
    } catch (error) {
      logger.error('Remove member error:', error);
      errorResponse(res, 'Failed to remove member', 500);
    }
  }
);

module.exports = router;



