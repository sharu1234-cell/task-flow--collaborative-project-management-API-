const express = require('express');
const { body } = require('express-validator');
const { authenticate, authorize } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');
const { validate, paginationRules, idParamRule } = require('../middleware/validator');
const { successResponse, errorResponse } = require('../utils/response');
const { getPaginationParams, getPaginationMeta } = require('../utils/pagination');
const Project = require('../models/Project');
const logger = require('../config/logger');
const { createActivity } = require('../models/Activity');

const router = express.Router();

// All routes require authentication
router.use(authenticate);
router.use(apiLimiter);

// Get all projects
router.get('/',
  paginationRules,
  validate,
  async (req, res) => {
    try {
      const pagination = getPaginationParams(req);
      const filters = {
        status: req.query.status,
        created_by: req.query.created_by,
        parent_id: req.query.parent_id === 'null' ? null : req.query.parent_id,
        search: req.query.search
      };

      const { projects, total } = await Project.findAll(filters, pagination);
      const meta = getPaginationMeta(pagination.page, pagination.limit, total);

      successResponse(res, { projects, meta }, 'Projects retrieved successfully');
    } catch (error) {
      logger.error('Get projects error:', error);
      errorResponse(res, 'Failed to retrieve projects', 500);
    }
  }
);

// Get project by ID
router.get('/:id',
  idParamRule,
  validate,
  async (req, res) => {
    try {
      const project = await Project.findById(req.params.id);
      if (!project) {
        return errorResponse(res, 'Project not found', 404);
      }
      successResponse(res, { project }, 'Project retrieved successfully');
    } catch (error) {
      logger.error('Get project error:', error);
      errorResponse(res, 'Failed to retrieve project', 500);
    }
  }
);

// Create project
router.post('/',
  [
    body('name').trim().notEmpty().withMessage('Project name is required'),
    body('description').optional().trim(),
    body('start_date').optional().isISO8601().withMessage('Invalid start date format'),
    body('end_date').optional().isISO8601().withMessage('Invalid end date format'),
    body('status').optional().isIn(['planning', 'active', 'on-hold', 'completed', 'cancelled']),
    body('parent_id').optional().isInt({ min: 1 })
  ],
  validate,
  async (req, res) => {
    try {
      const projectData = {
        ...req.body,
        created_by: req.user.id
      };

      const project = await Project.create(projectData);
      
      // Create activity
      await createActivity({
        project_id: project.id,
        user_id: req.user.id,
        type: 'project_created',
        description: `Project "${project.name}" was created`
      });

      successResponse(res, { project }, 'Project created successfully', 201);
    } catch (error) {
      logger.error('Create project error:', error);
      errorResponse(res, 'Failed to create project', 500);
    }
  }
);

// Update project
router.put('/:id',
  idParamRule,
  [
    body('name').optional().trim().notEmpty(),
    body('description').optional().trim(),
    body('start_date').optional().isISO8601(),
    body('end_date').optional().isISO8601(),
    body('status').optional().isIn(['planning', 'active', 'on-hold', 'completed', 'cancelled']),
    body('parent_id').optional().isInt({ min: 1 }).or().equals(null)
  ],
  validate,
  async (req, res) => {
    try {
      const project = await Project.findById(req.params.id);
      if (!project) {
        return errorResponse(res, 'Project not found', 404);
      }

      const updatedProject = await Project.update(req.params.id, req.body);
      
      // Create activity
      await createActivity({
        project_id: updatedProject.id,
        user_id: req.user.id,
        type: 'project_updated',
        description: `Project "${updatedProject.name}" was updated`
      });

      successResponse(res, { project: updatedProject }, 'Project updated successfully');
    } catch (error) {
      logger.error('Update project error:', error);
      errorResponse(res, 'Failed to update project', 500);
    }
  }
);

// Delete project
router.delete('/:id',
  idParamRule,
  validate,
  authorize('admin', 'manager'),
  async (req, res) => {
    try {
      const project = await Project.findById(req.params.id);
      if (!project) {
        return errorResponse(res, 'Project not found', 404);
      }

      await Project.delete(req.params.id);
      successResponse(res, null, 'Project deleted successfully');
    } catch (error) {
      logger.error('Delete project error:', error);
      errorResponse(res, 'Failed to delete project', 500);
    }
  }
);

// Get project hierarchy
router.get('/:id/hierarchy',
  idParamRule,
  validate,
  async (req, res) => {
    try {
      const project = await Project.findById(req.params.id);
      if (!project) {
        return errorResponse(res, 'Project not found', 404);
      }

      const hierarchy = await Project.getHierarchy(req.params.id);
      successResponse(res, { hierarchy }, 'Project hierarchy retrieved successfully');
    } catch (error) {
      logger.error('Get hierarchy error:', error);
      errorResponse(res, 'Failed to retrieve hierarchy', 500);
    }
  }
);

module.exports = router;



