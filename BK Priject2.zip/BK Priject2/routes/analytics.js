const express = require('express');
const { authenticate } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');
const { validate } = require('../middleware/validator');
const { successResponse, errorResponse } = require('../utils/response');
const { promisePool } = require('../config/database');
const logger = require('../config/logger');

const router = express.Router();

router.use(authenticate);
router.use(apiLimiter);

// Get project progress
router.get('/projects/:id/progress',
  async (req, res) => {
    try {
      const { id } = req.params;

      // Get task statistics
      const [taskStats] = await promisePool.execute(
        `SELECT 
          COUNT(*) as total_tasks,
          SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) as completed_tasks,
          SUM(CASE WHEN status = 'in-progress' THEN 1 ELSE 0 END) as in_progress_tasks,
          SUM(CASE WHEN status = 'todo' THEN 1 ELSE 0 END) as todo_tasks,
          SUM(CASE WHEN status = 'blocked' THEN 1 ELSE 0 END) as blocked_tasks,
          SUM(estimated_hours) as total_estimated_hours
         FROM tasks 
         WHERE project_id = ?`,
        [id]
      );

      const stats = taskStats[0];
      const progressPercentage = stats.total_tasks > 0 
        ? Math.round((stats.completed_tasks / stats.total_tasks) * 100) 
        : 0;

      successResponse(res, {
        progress: {
          ...stats,
          progress_percentage: progressPercentage
        }
      }, 'Project progress retrieved successfully');
    } catch (error) {
      logger.error('Get project progress error:', error);
      errorResponse(res, 'Failed to retrieve project progress', 500);
    }
  }
);

// Get team productivity metrics
router.get('/teams/:id/productivity',
  async (req, res) => {
    try {
      const { id } = req.params;

      // Get team members
      const [members] = await promisePool.execute(
        'SELECT user_id FROM team_members WHERE team_id = ?',
        [id]
      );

      const memberIds = members.map(m => m.user_id);

      if (memberIds.length === 0) {
        return successResponse(res, { productivity: [] }, 'No team members found');
      }

      // Get productivity metrics for each member
      const placeholders = memberIds.map(() => '?').join(',');
      const [productivity] = await promisePool.execute(
        `SELECT 
          u.id,
          u.name,
          COUNT(DISTINCT t.id) as total_tasks,
          SUM(CASE WHEN t.status = 'done' THEN 1 ELSE 0 END) as completed_tasks,
          SUM(t.estimated_hours) as estimated_hours,
          COUNT(DISTINCT c.id) as comments_count
         FROM users u
         LEFT JOIN task_assignees ta ON u.id = ta.user_id
         LEFT JOIN tasks t ON ta.task_id = t.id AND t.project_id IN (
           SELECT project_id FROM teams WHERE id = ?
         )
         LEFT JOIN comments c ON c.user_id = u.id
         WHERE u.id IN (${placeholders})
         GROUP BY u.id, u.name`,
        [id, ...memberIds]
      );

      successResponse(res, { productivity }, 'Team productivity retrieved successfully');
    } catch (error) {
      logger.error('Get team productivity error:', error);
      errorResponse(res, 'Failed to retrieve team productivity', 500);
    }
  }
);

// Get burndown chart data
router.get('/projects/:id/burndown',
  async (req, res) => {
    try {
      const { id } = req.params;
      const { days = 30 } = req.query;

      // Get project start date
      const [projects] = await promisePool.execute(
        'SELECT start_date, end_date FROM projects WHERE id = ?',
        [id]
      );

      if (projects.length === 0) {
        return errorResponse(res, 'Project not found', 404);
      }

      // Get task completion over time
      const [burndown] = await promisePool.execute(
        `SELECT 
          DATE(created_at) as date,
          COUNT(*) as tasks_created,
          SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END) as tasks_completed
         FROM tasks
         WHERE project_id = ?
         AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
         GROUP BY DATE(created_at)
         ORDER BY date ASC`,
        [id, days]
      );

      successResponse(res, { burndown }, 'Burndown data retrieved successfully');
    } catch (error) {
      logger.error('Get burndown error:', error);
      errorResponse(res, 'Failed to retrieve burndown data', 500);
    }
  }
);

// Get custom report
router.get('/reports',
  async (req, res) => {
    try {
      const { project_id, start_date, end_date, status } = req.query;

      let query = `SELECT 
                    p.id as project_id,
                    p.name as project_name,
                    COUNT(DISTINCT t.id) as total_tasks,
                    SUM(CASE WHEN t.status = 'done' THEN 1 ELSE 0 END) as completed_tasks,
                    SUM(t.estimated_hours) as total_hours,
                    COUNT(DISTINCT tm.user_id) as team_size,
                    COUNT(DISTINCT c.id) as total_comments
                   FROM projects p
                   LEFT JOIN tasks t ON p.id = t.project_id
                   LEFT JOIN teams te ON p.id = te.project_id
                   LEFT JOIN team_members tm ON te.id = tm.team_id
                   LEFT JOIN comments c ON p.id = c.project_id
                   WHERE 1=1`;
      const params = [];

      if (project_id) {
        query += ' AND p.id = ?';
        params.push(project_id);
      }
      if (start_date) {
        query += ' AND p.created_at >= ?';
        params.push(start_date);
      }
      if (end_date) {
        query += ' AND p.created_at <= ?';
        params.push(end_date);
      }
      if (status) {
        query += ' AND p.status = ?';
        params.push(status);
      }

      query += ' GROUP BY p.id, p.name';

      const [reports] = await promisePool.execute(query, params);

      successResponse(res, { reports }, 'Report generated successfully');
    } catch (error) {
      logger.error('Get report error:', error);
      errorResponse(res, 'Failed to generate report', 500);
    }
  }
);

module.exports = router;



