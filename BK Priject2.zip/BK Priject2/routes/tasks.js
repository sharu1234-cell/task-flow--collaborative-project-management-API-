const express = require('express');
const { body } = require('express-validator');
const { authenticate } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');
const { validate, paginationRules, idParamRule } = require('../middleware/validator');
const { successResponse, errorResponse } = require('../utils/response');
const { getPaginationParams, getPaginationMeta } = require('../utils/pagination');
const Task = require('../models/Task');
const logger = require('../config/logger');
const { createActivity } = require('../models/Activity');

const router = express.Router();

router.use(authenticate);
router.use(apiLimiter);

// Get all tasks
router.get('/',
  paginationRules,
  validate,
  async (req, res) => {
    try {
      const pagination = getPaginationParams(req);
      const filters = {
        project_id: req.query.project_id,
        status: req.query.status,
        priority: req.query.priority,
        assignee_id: req.query.assignee_id,
        created_by: req.query.created_by,
        search: req.query.search
      };

      const { tasks, total } = await Task.findAll(filters, pagination);
      const meta = getPaginationMeta(pagination.page, pagination.limit, total);

      successResponse(res, { tasks, meta }, 'Tasks retrieved successfully');
    } catch (error) {
      logger.error('Get tasks error:', error);
      errorResponse(res, 'Failed to retrieve tasks', 500);
    }
  }
);

// Get task by ID
router.get('/:id',
  idParamRule,
  validate,
  async (req, res) => {
    try {
      const task = await Task.findById(req.params.id);
      if (!task) {
        return errorResponse(res, 'Task not found', 404);
      }

      // Get assignees and dependencies
      const assignees = await Task.getAssignees(req.params.id);
      const dependencies = await Task.getDependencies(req.params.id);

      successResponse(res, { 
        task: {
          ...task,
          assignees,
          dependencies
        }
      }, 'Task retrieved successfully');
    } catch (error) {
      logger.error('Get task error:', error);
      errorResponse(res, 'Failed to retrieve task', 500);
    }
  }
);

// Create task
router.post('/',
  [
    body('title').trim().notEmpty().withMessage('Task title is required'),
    body('description').optional().trim(),
    body('project_id').isInt({ min: 1 }).withMessage('Valid project ID is required'),
    body('priority').optional().isIn(['low', 'medium', 'high', 'urgent']),
    body('status').optional().isIn(['todo', 'in-progress', 'review', 'done', 'blocked']),
    body('due_date').optional().isISO8601(),
    body('estimated_hours').optional().isFloat({ min: 0 })
  ],
  validate,
  async (req, res) => {
    try {
      const taskData = {
        ...req.body,
        created_by: req.user.id
      };

      const task = await Task.create(taskData);
      
      // Create activity
      await createActivity({
        project_id: task.project_id,
        user_id: req.user.id,
        type: 'task_created',
        description: `Task "${task.title}" was created`
      });

      successResponse(res, { task }, 'Task created successfully', 201);
    } catch (error) {
      logger.error('Create task error:', error);
      errorResponse(res, 'Failed to create task', 500);
    }
  }
);

// Update task
router.put('/:id',
  idParamRule,
  [
    body('title').optional().trim().notEmpty(),
    body('description').optional().trim(),
    body('priority').optional().isIn(['low', 'medium', 'high', 'urgent']),
    body('status').optional().isIn(['todo', 'in-progress', 'review', 'done', 'blocked']),
    body('due_date').optional().isISO8601(),
    body('estimated_hours').optional().isFloat({ min: 0 })
  ],
  validate,
  async (req, res) => {
    try {
      const task = await Task.findById(req.params.id);
      if (!task) {
        return errorResponse(res, 'Task not found', 404);
      }

      const updatedTask = await Task.update(req.params.id, req.body);
      
      // Create activity
      await createActivity({
        project_id: updatedTask.project_id,
        user_id: req.user.id,
        type: 'task_updated',
        description: `Task "${updatedTask.title}" was updated`
      });

      successResponse(res, { task: updatedTask }, 'Task updated successfully');
    } catch (error) {
      logger.error('Update task error:', error);
      errorResponse(res, 'Failed to update task', 500);
    }
  }
);

// Delete task
router.delete('/:id',
  idParamRule,
  validate,
  async (req, res) => {
    try {
      const task = await Task.findById(req.params.id);
      if (!task) {
        return errorResponse(res, 'Task not found', 404);
      }

      await Task.delete(req.params.id);
      successResponse(res, null, 'Task deleted successfully');
    } catch (error) {
      logger.error('Delete task error:', error);
      errorResponse(res, 'Failed to delete task', 500);
    }
  }
);

// Assign user to task
router.post('/:id/assignees',
  idParamRule,
  [body('user_id').isInt({ min: 1 }).withMessage('Valid user ID is required')],
  validate,
  async (req, res) => {
    try {
      const task = await Task.findById(req.params.id);
      if (!task) {
        return errorResponse(res, 'Task not found', 404);
      }

      await Task.addAssignee(req.params.id, req.body.user_id);
      const assignees = await Task.getAssignees(req.params.id);
      
      // Create activity
      await createActivity({
        project_id: task.project_id,
        user_id: req.user.id,
        type: 'task_assigned',
        description: `User assigned to task "${task.title}"`
      });

      successResponse(res, { assignees }, 'User assigned successfully');
    } catch (error) {
      logger.error('Assign user error:', error);
      errorResponse(res, 'Failed to assign user', 500);
    }
  }
);

// Remove assignee from task
router.delete('/:id/assignees/:userId',
  idParamRule,
  [body('userId').isInt({ min: 1 })],
  validate,
  async (req, res) => {
    try {
      await Task.removeAssignee(req.params.id, req.params.userId);
      successResponse(res, null, 'Assignee removed successfully');
    } catch (error) {
      logger.error('Remove assignee error:', error);
      errorResponse(res, 'Failed to remove assignee', 500);
    }
  }
);

// Add task dependency
router.post('/:id/dependencies',
  idParamRule,
  [body('depends_on_task_id').isInt({ min: 1 }).withMessage('Valid task ID is required')],
  validate,
  async (req, res) => {
    try {
      await Task.addDependency(req.params.id, req.body.depends_on_task_id);
      const dependencies = await Task.getDependencies(req.params.id);
      successResponse(res, { dependencies }, 'Dependency added successfully');
    } catch (error) {
      logger.error('Add dependency error:', error);
      errorResponse(res, 'Failed to add dependency', 500);
    }
  }
);

// Remove task dependency
router.delete('/:id/dependencies/:dependsOnId',
  idParamRule,
  async (req, res) => {
    try {
      await Task.removeDependency(req.params.id, req.params.dependsOnId);
      successResponse(res, null, 'Dependency removed successfully');
    } catch (error) {
      logger.error('Remove dependency error:', error);
      errorResponse(res, 'Failed to remove dependency', 500);
    }
  }
);

module.exports = router;



