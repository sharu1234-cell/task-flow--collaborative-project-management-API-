const express = require('express');
const { body } = require('express-validator');
const { authenticate } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');
const { validate, paginationRules, idParamRule } = require('../middleware/validator');
const { successResponse, errorResponse } = require('../utils/response');
const { getPaginationParams, getPaginationMeta } = require('../utils/pagination');
const { promisePool } = require('../config/database');
const logger = require('../config/logger');
const { createActivity } = require('../models/Activity');
const { createNotification } = require('../models/Notification');

const router = express.Router();

router.use(authenticate);
router.use(apiLimiter);

// Get comments for a task or project
router.get('/',
  paginationRules,
  validate,
  async (req, res) => {
    try {
      const pagination = getPaginationParams(req);
      const { task_id, project_id } = req.query;

      if (!task_id && !project_id) {
        return errorResponse(res, 'task_id or project_id is required', 400);
      }

      let query = `SELECT c.*, 
                          u.name as author_name, u.email as author_email,
                          (SELECT COUNT(*) FROM comments WHERE parent_id = c.id) as reply_count
                   FROM comments c
                   JOIN users u ON c.user_id = u.id
                   WHERE 1=1`;
      const params = [];

      if (task_id) {
        query += ' AND c.task_id = ?';
        params.push(task_id);
      }
      if (project_id) {
        query += ' AND c.project_id = ?';
        params.push(project_id);
      }

      query += ' ORDER BY c.created_at ASC LIMIT ? OFFSET ?';
      params.push(pagination.limit, pagination.offset);

      const [comments] = await promisePool.execute(query, params);

      // Get total count
      let countQuery = 'SELECT COUNT(*) as total FROM comments WHERE 1=1';
      const countParams = [];
      if (task_id) {
        countQuery += ' AND task_id = ?';
        countParams.push(task_id);
      }
      if (project_id) {
        countQuery += ' AND project_id = ?';
        countParams.push(project_id);
      }

      const [countResult] = await promisePool.execute(countQuery, countParams);
      const total = countResult[0].total;
      const meta = getPaginationMeta(pagination.page, pagination.limit, total);

      successResponse(res, { comments, meta }, 'Comments retrieved successfully');
    } catch (error) {
      logger.error('Get comments error:', error);
      errorResponse(res, 'Failed to retrieve comments', 500);
    }
  }
);

// Create comment
router.post('/',
  [
    body('content').trim().notEmpty().withMessage('Comment content is required'),
    body('task_id').optional().isInt({ min: 1 }),
    body('project_id').optional().isInt({ min: 1 }),
    body('parent_id').optional().isInt({ min: 1 })
  ],
  validate,
  async (req, res) => {
    try {
      const { content, task_id, project_id, parent_id } = req.body;

      if (!task_id && !project_id) {
        return errorResponse(res, 'task_id or project_id is required', 400);
      }

      const [result] = await promisePool.execute(
        `INSERT INTO comments (content, task_id, project_id, parent_id, user_id, created_at) 
         VALUES (?, ?, ?, ?, ?, NOW())`,
        [content, task_id || null, project_id || null, parent_id || null, req.user.id]
      );

      const [comments] = await promisePool.execute(
        `SELECT c.*, u.name as author_name, u.email as author_email 
         FROM comments c
         JOIN users u ON c.user_id = u.id
         WHERE c.id = ?`,
        [result.insertId]
      );

      // Create activity
      if (task_id) {
        await createActivity({
          project_id: project_id,
          user_id: req.user.id,
          type: 'comment_added',
          description: `Comment added to task`
        });

        // Notify task assignees
        const [assignees] = await promisePool.execute(
          'SELECT DISTINCT user_id FROM task_assignees WHERE task_id = ? AND user_id != ?',
          [task_id, req.user.id]
        );

        for (const assignee of assignees) {
          await createNotification({
            user_id: assignee.user_id,
            type: 'comment',
            message: `${req.user.name} commented on a task`,
            related_id: task_id,
            related_type: 'task'
          });
        }
      }

      successResponse(res, { comment: comments[0] }, 'Comment created successfully', 201);
    } catch (error) {
      logger.error('Create comment error:', error);
      errorResponse(res, 'Failed to create comment', 500);
    }
  }
);

// Update comment
router.put('/:id',
  idParamRule,
  [body('content').trim().notEmpty().withMessage('Comment content is required')],
  validate,
  async (req, res) => {
    try {
      const [comments] = await promisePool.execute(
        'SELECT * FROM comments WHERE id = ?',
        [req.params.id]
      );

      if (comments.length === 0) {
        return errorResponse(res, 'Comment not found', 404);
      }

      if (comments[0].user_id !== req.user.id) {
        return errorResponse(res, 'Unauthorized to update this comment', 403);
      }

      await promisePool.execute(
        'UPDATE comments SET content = ?, updated_at = NOW() WHERE id = ?',
        [req.body.content, req.params.id]
      );

      const [updated] = await promisePool.execute(
        `SELECT c.*, u.name as author_name, u.email as author_email 
         FROM comments c
         JOIN users u ON c.user_id = u.id
         WHERE c.id = ?`,
        [req.params.id]
      );

      successResponse(res, { comment: updated[0] }, 'Comment updated successfully');
    } catch (error) {
      logger.error('Update comment error:', error);
      errorResponse(res, 'Failed to update comment', 500);
    }
  }
);

// Delete comment
router.delete('/:id',
  idParamRule,
  validate,
  async (req, res) => {
    try {
      const [comments] = await promisePool.execute(
        'SELECT * FROM comments WHERE id = ?',
        [req.params.id]
      );

      if (comments.length === 0) {
        return errorResponse(res, 'Comment not found', 404);
      }

      if (comments[0].user_id !== req.user.id) {
        return errorResponse(res, 'Unauthorized to delete this comment', 403);
      }

      await promisePool.execute('DELETE FROM comments WHERE id = ?', [req.params.id]);
      successResponse(res, null, 'Comment deleted successfully');
    } catch (error) {
      logger.error('Delete comment error:', error);
      errorResponse(res, 'Failed to delete comment', 500);
    }
  }
);

module.exports = router;



