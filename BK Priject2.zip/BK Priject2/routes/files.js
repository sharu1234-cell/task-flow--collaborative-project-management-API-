const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { authenticate } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');
const { validate, idParamRule } = require('../middleware/validator');
const { successResponse, errorResponse } = require('../utils/response');
const { promisePool } = require('../config/database');
const logger = require('../config/logger');
const { createActivity } = require('../models/Activity');

const router = express.Router();

router.use(authenticate);
router.use(apiLimiter);

// Ensure upload directory exists
const uploadDir = process.env.UPLOAD_DIR || './uploads';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024 // 10MB default
  },
  fileFilter: (req, file, cb) => {
    // Allow all file types for now
    cb(null, true);
  }
});

// Upload file
router.post('/upload',
  upload.single('file'),
  async (req, res) => {
    try {
      if (!req.file) {
        return errorResponse(res, 'No file uploaded', 400);
      }

      const { task_id, project_id } = req.body;

      if (!task_id && !project_id) {
        // Delete uploaded file if no association
        fs.unlinkSync(req.file.path);
        return errorResponse(res, 'task_id or project_id is required', 400);
      }

      const [result] = await promisePool.execute(
        `INSERT INTO files (filename, original_filename, file_path, file_size, mime_type, task_id, project_id, uploaded_by, created_at) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          req.file.filename,
          req.file.originalname,
          req.file.path,
          req.file.size,
          req.file.mimetype,
          task_id || null,
          project_id || null,
          req.user.id
        ]
      );

      const [files] = await promisePool.execute(
        `SELECT f.*, u.name as uploader_name 
         FROM files f
         JOIN users u ON f.uploaded_by = u.id
         WHERE f.id = ?`,
        [result.insertId]
      );

      // Create activity
      if (task_id || project_id) {
        await createActivity({
          project_id: project_id,
          user_id: req.user.id,
          type: 'file_uploaded',
          description: `File "${req.file.originalname}" was uploaded`
        });
      }

      successResponse(res, { file: files[0] }, 'File uploaded successfully', 201);
    } catch (error) {
      logger.error('Upload file error:', error);
      errorResponse(res, 'Failed to upload file', 500);
    }
  }
);

// Get files
router.get('/',
  async (req, res) => {
    try {
      const { task_id, project_id } = req.query;

      let query = `SELECT f.*, u.name as uploader_name 
                   FROM files f
                   JOIN users u ON f.uploaded_by = u.id
                   WHERE 1=1`;
      const params = [];

      if (task_id) {
        query += ' AND f.task_id = ?';
        params.push(task_id);
      }
      if (project_id) {
        query += ' AND f.project_id = ?';
        params.push(project_id);
      }

      query += ' ORDER BY f.created_at DESC';

      const [files] = await promisePool.execute(query, params);
      successResponse(res, { files }, 'Files retrieved successfully');
    } catch (error) {
      logger.error('Get files error:', error);
      errorResponse(res, 'Failed to retrieve files', 500);
    }
  }
);

// Download file
router.get('/:id/download',
  idParamRule,
  validate,
  async (req, res) => {
    try {
      const [files] = await promisePool.execute(
        'SELECT * FROM files WHERE id = ?',
        [req.params.id]
      );

      if (files.length === 0) {
        return errorResponse(res, 'File not found', 404);
      }

      const file = files[0];
      const filePath = path.join(__dirname, '..', file.file_path);

      if (!fs.existsSync(filePath)) {
        return errorResponse(res, 'File not found on server', 404);
      }

      res.download(filePath, file.original_filename);
    } catch (error) {
      logger.error('Download file error:', error);
      errorResponse(res, 'Failed to download file', 500);
    }
  }
);

// Delete file
router.delete('/:id',
  idParamRule,
  validate,
  async (req, res) => {
    try {
      const [files] = await promisePool.execute(
        'SELECT * FROM files WHERE id = ?',
        [req.params.id]
      );

      if (files.length === 0) {
        return errorResponse(res, 'File not found', 404);
      }

      const file = files[0];

      // Check permission
      if (file.uploaded_by !== req.user.id) {
        return errorResponse(res, 'Unauthorized to delete this file', 403);
      }

      // Delete file from filesystem
      const filePath = path.join(__dirname, '..', file.file_path);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }

      // Delete from database
      await promisePool.execute('DELETE FROM files WHERE id = ?', [req.params.id]);
      successResponse(res, null, 'File deleted successfully');
    } catch (error) {
      logger.error('Delete file error:', error);
      errorResponse(res, 'Failed to delete file', 500);
    }
  }
);

module.exports = router;



