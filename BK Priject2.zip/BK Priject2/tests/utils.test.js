const { getPaginationParams, getPaginationMeta } = require('../utils/pagination');
const { successResponse, errorResponse } = require('../utils/response');

describe('Utils', () => {
  describe('Pagination Utils', () => {
    it('should return default pagination params', () => {
      const req = { query: {} };
      const params = getPaginationParams(req);
      expect(params.page).toBe(1);
      expect(params.limit).toBe(10);
      expect(params.offset).toBe(0);
    });

    it('should return custom pagination params', () => {
      const req = { query: { page: '2', limit: '20' } };
      const params = getPaginationParams(req);
      expect(params.page).toBe(2);
      expect(params.limit).toBe(20);
      expect(params.offset).toBe(20);
    });

    it('should generate pagination meta', () => {
      const meta = getPaginationMeta(2, 10, 25);
      expect(meta.currentPage).toBe(2);
      expect(meta.totalPages).toBe(3);
      expect(meta.totalItems).toBe(25);
      expect(meta.itemsPerPage).toBe(10);
      expect(meta.hasNextPage).toBe(true);
      expect(meta.hasPreviousPage).toBe(true);
    });
  });

  describe('Response Utils', () => {
    it('should create success response', () => {
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      };
      successResponse(res, { data: 'test' }, 'Success', 200);
      expect(res.status).toHaveBeenCalledWith(200);
      expect(res.json).toHaveBeenCalledWith({
        success: true,
        message: 'Success',
        data: { data: 'test' }
      });
    });

    it('should create error response', () => {
      const res = {
        status: jest.fn().mockReturnThis(),
        json: jest.fn()
      };
      errorResponse(res, 'Error', 400);
      expect(res.status).toHaveBeenCalledWith(400);
      expect(res.json).toHaveBeenCalledWith({
        success: false,
        message: 'Error'
      });
    });
  });
});



