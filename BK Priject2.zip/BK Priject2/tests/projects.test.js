const request = require('supertest');
const { app } = require('../server');
const { promisePool } = require('../config/database');

describe('Projects API', () => {
  let authToken;
  let projectId;

  beforeAll(async () => {
    // Login to get token
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({
        email: 'admin@taskflow.com',
        password: 'password123'
      });
    authToken = res.body.data.token;
  });

  describe('POST /api/v1/projects', () => {
    it('should create a new project', async () => {
      const res = await request(app)
        .post('/api/v1/projects')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          name: 'Test Project',
          description: 'Test project description',
          status: 'planning'
        });

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.data.project).toHaveProperty('id');
      projectId = res.body.data.project.id;
    });

    it('should require authentication', async () => {
      const res = await request(app)
        .post('/api/v1/projects')
        .send({
          name: 'Test Project'
        });

      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/v1/projects', () => {
    it('should get all projects', async () => {
      const res = await request(app)
        .get('/api/v1/projects')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data).toHaveProperty('projects');
      expect(res.body.data).toHaveProperty('meta');
    });

    it('should support pagination', async () => {
      const res = await request(app)
        .get('/api/v1/projects?page=1&limit=5')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.status).toBe(200);
      expect(res.body.data.meta.currentPage).toBe(1);
      expect(res.body.data.meta.itemsPerPage).toBe(5);
    });
  });

  describe('GET /api/v1/projects/:id', () => {
    it('should get project by ID', async () => {
      const res = await request(app)
        .get(`/api/v1/projects/${projectId}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data.project.id).toBe(projectId);
    });

    it('should return 404 for non-existent project', async () => {
      const res = await request(app)
        .get('/api/v1/projects/99999')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.status).toBe(404);
    });
  });

  describe('PUT /api/v1/projects/:id', () => {
    it('should update project', async () => {
      const res = await request(app)
        .put(`/api/v1/projects/${projectId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          status: 'active'
        });

      expect(res.status).toBe(200);
      expect(res.body.data.project.status).toBe('active');
    });
  });

  afterAll(async () => {
    if (projectId) {
      await promisePool.execute('DELETE FROM projects WHERE id = ?', [projectId]);
    }
  });
});



