const request = require('supertest');
const { app } = require('../server');
const { promisePool } = require('../config/database');

describe('Tasks API', () => {
  let authToken;
  let projectId;
  let taskId;

  beforeAll(async () => {
    const res = await request(app)
      .post('/api/v1/auth/login')
      .send({
        email: 'admin@taskflow.com',
        password: 'password123'
      });
    authToken = res.body.data.token;

    // Create a project for testing
    const projectRes = await request(app)
      .post('/api/v1/projects')
      .set('Authorization', `Bearer ${authToken}`)
      .send({
        name: 'Test Project for Tasks',
        description: 'Test project'
      });
    projectId = projectRes.body.data.project.id;
  });

  describe('POST /api/v1/tasks', () => {
    it('should create a new task', async () => {
      const res = await request(app)
        .post('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          title: 'Test Task',
          description: 'Test task description',
          project_id: projectId,
          priority: 'high',
          status: 'todo'
        });

      expect(res.status).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.data.task).toHaveProperty('id');
      taskId = res.body.data.task.id;
    });
  });

  describe('GET /api/v1/tasks', () => {
    it('should get all tasks', async () => {
      const res = await request(app)
        .get('/api/v1/tasks')
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data).toHaveProperty('tasks');
    });

    it('should filter tasks by project', async () => {
      const res = await request(app)
        .get(`/api/v1/tasks?project_id=${projectId}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.status).toBe(200);
    });
  });

  describe('GET /api/v1/tasks/:id', () => {
    it('should get task by ID', async () => {
      const res = await request(app)
        .get(`/api/v1/tasks/${taskId}`)
        .set('Authorization', `Bearer ${authToken}`);

      expect(res.status).toBe(200);
      expect(res.body.data.task.id).toBe(taskId);
    });
  });

  describe('PUT /api/v1/tasks/:id', () => {
    it('should update task', async () => {
      const res = await request(app)
        .put(`/api/v1/tasks/${taskId}`)
        .set('Authorization', `Bearer ${authToken}`)
        .send({
          status: 'in-progress'
        });

      expect(res.status).toBe(200);
      expect(res.body.data.task.status).toBe('in-progress');
    });
  });

  afterAll(async () => {
    if (taskId) {
      await promisePool.execute('DELETE FROM tasks WHERE id = ?', [taskId]);
    }
    if (projectId) {
      await promisePool.execute('DELETE FROM projects WHERE id = ?', [projectId]);
    }
  });
});



