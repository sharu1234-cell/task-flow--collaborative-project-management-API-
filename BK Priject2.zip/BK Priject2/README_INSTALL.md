# ⚡ QUICK INSTALL GUIDE

## ❌ ERROR: "command not found" or "npm is not recognized"

**This means Node.js is NOT installed on your computer.**

---

## ✅ SOLUTION: Install Node.js (5 minutes)

### Method 1: Automatic (Easiest)

1. **Double-click** `install_nodejs.ps1` file
   - If it asks for permission, click "Yes"
   - It will guide you through installation

### Method 2: Manual Installation

1. **Open browser** → Go to: **https://nodejs.org/**
2. **Click** the green "LTS" button (left side)
3. **Download** the Windows installer (.msi file)
4. **Run** the downloaded file
5. **Click Next** through all screens
6. **Make sure** "Add to PATH" is checked ✓
7. **Click Install** and wait
8. **Close** your terminal completely
9. **Open a NEW terminal**
10. **Run:** `npm install`

---

## ✅ Verify Installation

After installing, open a NEW terminal and type:

```bash
node --version
npm --version
```

**If you see numbers** (like v20.10.0), you're ready!

---

## 🚀 Then Install Project

```bash
cd "C:\Users\SHARVANI\BK Priject2"
npm install
```

---

## ⚠️ IMPORTANT NOTES

- **You MUST install Node.js FIRST** - it's not included with this project
- **Restart terminal** after installing Node.js
- **Don't skip** the "Add to PATH" option during installation
- If still not working, **restart your computer**

---

## 📋 What is Node.js?

Node.js is a runtime environment needed to run JavaScript on your computer.
npm (Node Package Manager) comes with Node.js and is used to install project dependencies.

**You cannot run `npm install` without Node.js installed!**



