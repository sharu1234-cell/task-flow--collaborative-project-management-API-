# Fix npm "command not found" Error

## Problem
Node.js is installed (`node --version` works) but npm doesn't work (`npm --version` fails).

## Quick Fixes

### Solution 1: Use Full Path (Temporary Fix)

Try running npm with full path:

```bash
"C:\Program Files\nodejs\npm.cmd" --version
```

If that works, you can use it to install dependencies:

```bash
"C:\Program Files\nodejs\npm.cmd" install
```

### Solution 2: Add Node.js to PATH (Permanent Fix)

1. **Find Node.js installation:**
   - Usually at: `C:\Program Files\nodejs\`
   - Or: `C:\Program Files (x86)\nodejs\`

2. **Add to PATH:**
   - Press `Win + R`
   - Type: `sysdm.cpl` and press Enter
   - Go to **"Advanced"** tab
   - Click **"Environment Variables"**
   - Under **"System variables"**, find **"Path"**
   - Click **"Edit"**
   - Click **"New"**
   - Add: `C:\Program Files\nodejs\`
   - Click **OK** on all windows
   - **Close and reopen your terminal**

3. **Verify:**
   ```bash
   npm --version
   ```

### Solution 3: Reinstall Node.js (Recommended)

Sometimes npm gets corrupted. Reinstalling fixes it:

1. **Uninstall Node.js:**
   - Go to Settings → Apps
   - Find "Node.js" and uninstall it

2. **Download fresh installer:**
   - Go to: https://nodejs.org/
   - Download LTS version

3. **Install:**
   - Run installer
   - **IMPORTANT:** Check "Add to PATH" option
   - Complete installation

4. **Restart terminal** and verify:
   ```bash
   node --version
   npm --version
   ```

### Solution 4: Repair npm Installation

If Node.js is installed but npm is missing:

1. **Open PowerShell as Administrator**

2. **Navigate to Node.js folder:**
   ```powershell
   cd "C:\Program Files\nodejs"
   ```

3. **Check if npm files exist:**
   ```powershell
   dir npm*
   ```

4. **If npm.cmd exists, try:**
   ```powershell
   .\npm.cmd install -g npm@latest
   ```

### Solution 5: Use Node.js Command Prompt

Node.js installer usually creates a special command prompt:

1. Press `Win` key
2. Search for: **"Node.js command prompt"**
3. Use that terminal instead
4. npm should work there

## Quick Test Script

Run `fix_npm.bat` to automatically diagnose and fix the issue.

## After Fixing

Once npm works, install project dependencies:

```bash
cd "C:\Users\SHARVANI\BK Priject2"
npm install
```

Or if using full path:

```bash
"C:\Program Files\nodejs\npm.cmd" install
```

## Still Not Working?

1. **Restart your computer** after adding to PATH
2. Check if npm exists: `dir "C:\Program Files\nodejs\npm*"`
3. Try running: `node "C:\Program Files\nodejs\node_modules\npm\bin\npm-cli.js" --version`
4. Reinstall Node.js completely


