# Troubleshooting npm install Errors

## Common Issues and Solutions

### 1. npm is not recognized
**Error:** `npm : The term 'npm' is not recognized`

**Solution:**
- Install Node.js from https://nodejs.org/
- Restart your terminal after installation
- Verify installation: `node --version` and `npm --version`

### 2. Permission Errors (Windows)
**Error:** `EACCES` or permission denied

**Solution:**
- Run terminal as Administrator
- Or use: `npm install --no-optional`

### 3. Network/Proxy Issues
**Error:** `ETIMEDOUT` or network errors

**Solution:**
```bash
npm config set registry https://registry.npmjs.org/
npm install
```

### 4. Package Version Conflicts
**Error:** Peer dependency warnings

**Solution:**
- Already handled with `.npmrc` file (legacy-peer-deps=true)
- Or run: `npm install --legacy-peer-deps`

### 5. Cache Issues
**Error:** Corrupted cache

**Solution:**
```bash
npm cache clean --force
npm install
```

### 6. Python/Node-gyp Errors (Windows)
**Error:** `node-gyp` build errors

**Solution:**
```bash
npm install --global windows-build-tools
npm install
```

### 7. If All Else Fails
Try installing dependencies one by one:
```bash
npm install express mysql2 dotenv bcryptjs jsonwebtoken
npm install express-validator cors express-rate-limit multer
npm install socket.io moment uuid winston helmet compression
npm install --save-dev nodemon jest supertest
```

## Quick Fix Commands

```bash
# Clear cache and reinstall
npm cache clean --force
rm -rf node_modules package-lock.json
npm install

# Or on Windows PowerShell:
npm cache clean --force
Remove-Item -Recurse -Force node_modules, package-lock.json -ErrorAction SilentlyContinue
npm install
```



