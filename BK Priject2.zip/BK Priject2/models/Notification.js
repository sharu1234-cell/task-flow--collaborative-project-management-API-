const { promisePool } = require('../config/database');

const createNotification = async (notificationData) => {
  const { user_id, type, message, related_id = null, related_type = null } = notificationData;
  
  await promisePool.execute(
    `INSERT INTO notifications (user_id, type, message, related_id, related_type, is_read, created_at) 
     VALUES (?, ?, ?, ?, ?, 0, NOW())`,
    [user_id, type, message, related_id, related_type]
  );
  
  return true;
};

module.exports = { createNotification };



