const { promisePool } = require('../config/database');

class Project {
  static async create(projectData) {
    const { name, description, start_date, end_date, status = 'planning', parent_id, created_by } = projectData;
    
    const [result] = await promisePool.execute(
      `INSERT INTO projects (name, description, start_date, end_date, status, parent_id, created_by, created_at) 
       VALUES (?, ?, ?, ?, ?, ?, ?, NOW())`,
      [name, description, start_date, end_date, status, parent_id || null, created_by]
    );
    
    return this.findById(result.insertId);
  }

  static async findById(id) {
    const [projects] = await promisePool.execute(
      `SELECT p.*, 
              u.name as creator_name, u.email as creator_email,
              (SELECT COUNT(*) FROM projects WHERE parent_id = p.id) as subproject_count,
              (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count
       FROM projects p
       LEFT JOIN users u ON p.created_by = u.id
       WHERE p.id = ?`,
      [id]
    );
    return projects[0];
  }

  static async findAll(filters = {}, pagination = {}) {
    const { status, created_by, parent_id, search } = filters;
    const { limit, offset } = pagination;
    
    let query = `SELECT p.*, 
                        u.name as creator_name,
                        (SELECT COUNT(*) FROM projects WHERE parent_id = p.id) as subproject_count,
                        (SELECT COUNT(*) FROM tasks WHERE project_id = p.id) as task_count
                 FROM projects p
                 LEFT JOIN users u ON p.created_by = u.id
                 WHERE 1=1`;
    const params = [];
    
    if (status) {
      query += ' AND p.status = ?';
      params.push(status);
    }
    if (created_by) {
      query += ' AND p.created_by = ?';
      params.push(created_by);
    }
    if (parent_id !== undefined) {
      if (parent_id === null) {
        query += ' AND p.parent_id IS NULL';
      } else {
        query += ' AND p.parent_id = ?';
        params.push(parent_id);
      }
    }
    if (search) {
      query += ' AND (p.name LIKE ? OR p.description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }
    
    query += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);
    
    const [projects] = await promisePool.execute(query, params);
    
    // Get total count
    let countQuery = 'SELECT COUNT(*) as total FROM projects WHERE 1=1';
    const countParams = [];
    
    if (status) {
      countQuery += ' AND status = ?';
      countParams.push(status);
    }
    if (created_by) {
      countQuery += ' AND created_by = ?';
      countParams.push(created_by);
    }
    if (parent_id !== undefined) {
      if (parent_id === null) {
        countQuery += ' AND parent_id IS NULL';
      } else {
        countQuery += ' AND parent_id = ?';
        countParams.push(parent_id);
      }
    }
    if (search) {
      countQuery += ' AND (name LIKE ? OR description LIKE ?)';
      countParams.push(`%${search}%`, `%${search}%`);
    }
    
    const [countResult] = await promisePool.execute(countQuery, countParams);
    const total = countResult[0].total;
    
    return { projects, total };
  }

  static async update(id, updates) {
    const fields = [];
    const values = [];
    
    Object.keys(updates).forEach(key => {
      if (updates[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(updates[key]);
      }
    });
    
    if (fields.length === 0) return this.findById(id);
    
    values.push(id);
    await promisePool.execute(
      `UPDATE projects SET ${fields.join(', ')}, updated_at = NOW() WHERE id = ?`,
      values
    );
    
    return this.findById(id);
  }

  static async delete(id) {
    await promisePool.execute('DELETE FROM projects WHERE id = ?', [id]);
    return true;
  }

  static async getHierarchy(projectId) {
    const [projects] = await promisePool.execute(
      `WITH RECURSIVE project_tree AS (
        SELECT id, name, parent_id, 0 as level
        FROM projects
        WHERE id = ?
        UNION ALL
        SELECT p.id, p.name, p.parent_id, pt.level + 1
        FROM projects p
        INNER JOIN project_tree pt ON p.parent_id = pt.id
      )
      SELECT * FROM project_tree ORDER BY level, id`,
      [projectId]
    );
    return projects;
  }
}

module.exports = Project;



