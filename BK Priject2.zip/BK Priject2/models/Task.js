const { promisePool } = require('../config/database');

class Task {
  static async create(taskData) {
    const { 
      title, description, project_id, priority = 'medium', 
      status = 'todo', due_date, estimated_hours, created_by 
    } = taskData;
    
    const [result] = await promisePool.execute(
      `INSERT INTO tasks (title, description, project_id, priority, status, due_date, estimated_hours, created_by, created_at) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [title, description, project_id, priority, status, due_date, estimated_hours, created_by]
    );
    
    return this.findById(result.insertId);
  }

  static async findById(id) {
    const [tasks] = await promisePool.execute(
      `SELECT t.*, 
              p.name as project_name,
              u.name as creator_name,
              (SELECT COUNT(*) FROM task_dependencies WHERE task_id = t.id) as dependency_count,
              (SELECT COUNT(*) FROM task_assignees WHERE task_id = t.id) as assignee_count
       FROM tasks t
       LEFT JOIN projects p ON t.project_id = p.id
       LEFT JOIN users u ON t.created_by = u.id
       WHERE t.id = ?`,
      [id]
    );
    return tasks[0];
  }

  static async findAll(filters = {}, pagination = {}) {
    const { project_id, status, priority, assignee_id, created_by, search } = filters;
    const { limit, offset } = pagination;
    
    let query = `SELECT t.*, 
                        p.name as project_name,
                        u.name as creator_name
                 FROM tasks t
                 LEFT JOIN projects p ON t.project_id = p.id
                 LEFT JOIN users u ON t.created_by = u.id
                 WHERE 1=1`;
    const params = [];
    
    if (project_id) {
      query += ' AND t.project_id = ?';
      params.push(project_id);
    }
    if (status) {
      query += ' AND t.status = ?';
      params.push(status);
    }
    if (priority) {
      query += ' AND t.priority = ?';
      params.push(priority);
    }
    if (assignee_id) {
      query += ' AND EXISTS (SELECT 1 FROM task_assignees WHERE task_id = t.id AND user_id = ?)';
      params.push(assignee_id);
    }
    if (created_by) {
      query += ' AND t.created_by = ?';
      params.push(created_by);
    }
    if (search) {
      query += ' AND (t.title LIKE ? OR t.description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }
    
    query += ' ORDER BY t.created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);
    
    const [tasks] = await promisePool.execute(query, params);
    
    // Get total count
    let countQuery = 'SELECT COUNT(*) as total FROM tasks WHERE 1=1';
    const countParams = [];
    
    if (project_id) {
      countQuery += ' AND project_id = ?';
      countParams.push(project_id);
    }
    if (status) {
      countQuery += ' AND status = ?';
      countParams.push(status);
    }
    if (priority) {
      countQuery += ' AND priority = ?';
      countParams.push(priority);
    }
    if (assignee_id) {
      countQuery += ' AND EXISTS (SELECT 1 FROM task_assignees WHERE task_id = tasks.id AND user_id = ?)';
      countParams.push(assignee_id);
    }
    if (created_by) {
      countQuery += ' AND created_by = ?';
      countParams.push(created_by);
    }
    if (search) {
      countQuery += ' AND (title LIKE ? OR description LIKE ?)';
      countParams.push(`%${search}%`, `%${search}%`);
    }
    
    const [countResult] = await promisePool.execute(countQuery, countParams);
    const total = countResult[0].total;
    
    return { tasks, total };
  }

  static async update(id, updates) {
    const fields = [];
    const values = [];
    
    Object.keys(updates).forEach(key => {
      if (updates[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(updates[key]);
      }
    });
    
    if (fields.length === 0) return this.findById(id);
    
    values.push(id);
    await promisePool.execute(
      `UPDATE tasks SET ${fields.join(', ')}, updated_at = NOW() WHERE id = ?`,
      values
    );
    
    return this.findById(id);
  }

  static async delete(id) {
    await promisePool.execute('DELETE FROM tasks WHERE id = ?', [id]);
    return true;
  }

  static async addAssignee(taskId, userId) {
    await promisePool.execute(
      'INSERT IGNORE INTO task_assignees (task_id, user_id, assigned_at) VALUES (?, ?, NOW())',
      [taskId, userId]
    );
    return true;
  }

  static async removeAssignee(taskId, userId) {
    await promisePool.execute(
      'DELETE FROM task_assignees WHERE task_id = ? AND user_id = ?',
      [taskId, userId]
    );
    return true;
  }

  static async getAssignees(taskId) {
    const [assignees] = await promisePool.execute(
      `SELECT u.id, u.name, u.email, ta.assigned_at 
       FROM task_assignees ta
       JOIN users u ON ta.user_id = u.id
       WHERE ta.task_id = ?`,
      [taskId]
    );
    return assignees;
  }

  static async addDependency(taskId, dependsOnTaskId) {
    await promisePool.execute(
      'INSERT IGNORE INTO task_dependencies (task_id, depends_on_task_id, created_at) VALUES (?, ?, NOW())',
      [taskId, dependsOnTaskId]
    );
    return true;
  }

  static async removeDependency(taskId, dependsOnTaskId) {
    await promisePool.execute(
      'DELETE FROM task_dependencies WHERE task_id = ? AND depends_on_task_id = ?',
      [taskId, dependsOnTaskId]
    );
    return true;
  }

  static async getDependencies(taskId) {
    const [dependencies] = await promisePool.execute(
      `SELECT t.id, t.title, t.status, td.created_at 
       FROM task_dependencies td
       JOIN tasks t ON td.depends_on_task_id = t.id
       WHERE td.task_id = ?`,
      [taskId]
    );
    return dependencies;
  }
}

module.exports = Task;



