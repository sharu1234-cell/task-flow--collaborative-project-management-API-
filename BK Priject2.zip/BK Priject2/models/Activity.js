const { promisePool } = require('../config/database');

const createActivity = async (activityData) => {
  const { project_id, user_id, type, description, related_id = null, related_type = null } = activityData;
  
  await promisePool.execute(
    `INSERT INTO activities (project_id, user_id, type, description, related_id, related_type, created_at) 
     VALUES (?, ?, ?, ?, ?, ?, NOW())`,
    [project_id, user_id, type, description, related_id, related_type]
  );
  
  return true;
};

module.exports = { createActivity };



