const { promisePool } = require('../config/database');
const bcrypt = require('bcryptjs');

class User {
  static async create(userData) {
    const { email, password, name, role = 'member' } = userData;
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const [result] = await promisePool.execute(
      `INSERT INTO users (email, password, name, role, status, created_at) 
       VALUES (?, ?, ?, ?, 'active', NOW())`,
      [email, hashedPassword, name, role]
    );
    
    return this.findById(result.insertId);
  }

  static async findById(id) {
    const [users] = await promisePool.execute(
      'SELECT id, email, name, role, status, created_at FROM users WHERE id = ?',
      [id]
    );
    return users[0];
  }

  static async findByEmail(email) {
    const [users] = await promisePool.execute(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );
    return users[0];
  }

  static async update(id, updates) {
    const fields = [];
    const values = [];
    
    Object.keys(updates).forEach(key => {
      if (updates[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(updates[key]);
      }
    });
    
    if (fields.length === 0) return this.findById(id);
    
    values.push(id);
    await promisePool.execute(
      `UPDATE users SET ${fields.join(', ')}, updated_at = NOW() WHERE id = ?`,
      values
    );
    
    return this.findById(id);
  }

  static async verifyPassword(plainPassword, hashedPassword) {
    return bcrypt.compare(plainPassword, hashedPassword);
  }
}

module.exports = User;



