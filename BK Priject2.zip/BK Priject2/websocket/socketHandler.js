const jwt = require('jsonwebtoken');
const { promisePool } = require('../config/database');
const logger = require('../config/logger');

const socketHandler = (socket, io) => {
  logger.info(`Client connected: ${socket.id}`);

  // Authenticate socket connection
  socket.on('authenticate', async (token) => {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-in-production');
      
      const [users] = await promisePool.execute(
        'SELECT id, email, name FROM users WHERE id = ? AND status = "active"',
        [decoded.userId]
      );

      if (users.length === 0) {
        socket.emit('error', { message: 'Authentication failed' });
        return;
      }

      socket.userId = users[0].id;
      socket.user = users[0];
      
      // Join user's personal room
      socket.join(`user:${socket.userId}`);
      
      logger.info(`User authenticated via socket: ${socket.userId}`);
      socket.emit('authenticated', { user: users[0] });
    } catch (error) {
      logger.error('Socket authentication error:', error);
      socket.emit('error', { message: 'Invalid token' });
    }
  });

  // Join project room
  socket.on('join-project', (projectId) => {
    if (!socket.userId) {
      socket.emit('error', { message: 'Authentication required' });
      return;
    }
    socket.join(`project:${projectId}`);
    logger.info(`User ${socket.userId} joined project ${projectId}`);
  });

  // Leave project room
  socket.on('leave-project', (projectId) => {
    socket.leave(`project:${projectId}`);
    logger.info(`User ${socket.userId} left project ${projectId}`);
  });

  // Handle disconnection
  socket.on('disconnect', () => {
    logger.info(`Client disconnected: ${socket.id}`);
  });
};

// Helper function to emit to project room
const emitToProject = (io, projectId, event, data) => {
  io.to(`project:${projectId}`).emit(event, data);
};

// Helper function to emit to user
const emitToUser = (io, userId, event, data) => {
  io.to(`user:${userId}`).emit(event, data);
};

module.exports = socketHandler;
module.exports.emitToProject = emitToProject;
module.exports.emitToUser = emitToUser;



