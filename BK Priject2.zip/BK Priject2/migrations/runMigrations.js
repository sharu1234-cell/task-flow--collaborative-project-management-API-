const fs = require('fs');
const path = require('path');
const mysql = require('mysql2');
require('dotenv').config();

const connection = mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  port: process.env.DB_PORT || 3306,
  multipleStatements: true
});

const runMigrations = async () => {
  try {
    console.log('Running database migrations...');
    
    // Read schema file
    const schemaPath = path.join(__dirname, 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    // Execute schema
    connection.query(schema, (err, results) => {
      if (err) {
        console.error('Migration error:', err);
        process.exit(1);
      }
      
      console.log('Schema created successfully!');
      console.log('Running seed data...');
      
      // Read seed file
      const seedPath = path.join(__dirname, 'seedData.sql');
      const seed = fs.readFileSync(seedPath, 'utf8');
      
      // Execute seed data
      connection.query(seed, (err, results) => {
        if (err) {
          console.error('Seed error:', err);
          process.exit(1);
        }
        
        console.log('Seed data inserted successfully!');
        connection.end();
        process.exit(0);
      });
    });
  } catch (error) {
    console.error('Error:', error);
    connection.end();
    process.exit(1);
  }
};

runMigrations();



