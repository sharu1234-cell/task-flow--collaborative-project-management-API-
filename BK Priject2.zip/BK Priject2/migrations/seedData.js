const fs = require('fs');
const path = require('path');
const mysql = require('mysql2');
require('dotenv').config();

const connection = mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'taskflow_db',
  port: process.env.DB_PORT || 3306,
  multipleStatements: true
});

const runSeed = async () => {
  try {
    console.log('Running seed data...');
    
    // Read seed file
    const seedPath = path.join(__dirname, 'seedData.sql');
    const seed = fs.readFileSync(seedPath, 'utf8');
    
    // Execute seed data
    connection.query(seed, (err, results) => {
      if (err) {
        console.error('Seed error:', err);
        process.exit(1);
      }
      
      console.log('Seed data inserted successfully!');
      connection.end();
      process.exit(0);
    });
  } catch (error) {
    console.error('Error:', error);
    connection.end();
    process.exit(1);
  }
};

runSeed();



