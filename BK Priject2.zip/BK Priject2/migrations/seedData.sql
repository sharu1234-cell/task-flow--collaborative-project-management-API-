-- TaskFlow Sample Data
-- Insert sample data for testing

USE taskflow_db;

-- Insert sample users
-- Note: Run migrations/seedData.js to properly hash passwords, or use bcrypt to generate hashes
-- Default password for all users: "password123"
-- Example hash: $2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy
INSERT INTO users (email, password, name, role, status) VALUES
('admin@taskflow.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Admin User', 'admin', 'active'),
('manager@taskflow.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Manager User', 'manager', 'active'),
('john@taskflow.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'John Doe', 'member', 'active'),
('jane@taskflow.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Jane Smith', 'member', 'active'),
('bob@taskflow.com', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Bob Johnson', 'member', 'active');

-- Insert sample projects
INSERT INTO projects (name, description, start_date, end_date, status, created_by) VALUES
('Website Redesign', 'Complete redesign of company website with modern UI/UX', '2024-01-01', '2024-06-30', 'active', 1),
('Mobile App Development', 'Develop mobile application for iOS and Android', '2024-02-01', '2024-08-31', 'active', 2),
('API Integration', 'Integrate third-party APIs for payment processing', '2024-03-01', '2024-05-31', 'planning', 2);

-- Insert sub-projects
INSERT INTO projects (name, description, start_date, end_date, status, parent_id, created_by) VALUES
('Frontend Development', 'React-based frontend development', '2024-01-01', '2024-04-30', 'active', 1, 1),
('Backend Development', 'Node.js backend API development', '2024-01-15', '2024-05-15', 'active', 1, 1);

-- Insert teams
INSERT INTO teams (name, description, project_id, created_by) VALUES
('Frontend Team', 'Frontend development team', 1, 1),
('Backend Team', 'Backend development team', 1, 1),
('Mobile Team', 'Mobile app development team', 2, 2);

-- Insert team members
INSERT INTO team_members (team_id, user_id, role) VALUES
(1, 3, 'lead'),
(1, 4, 'member'),
(2, 5, 'lead'),
(2, 3, 'member'),
(3, 4, 'lead'),
(3, 5, 'member');

-- Insert tasks
INSERT INTO tasks (title, description, project_id, priority, status, due_date, estimated_hours, created_by) VALUES
('Design Homepage', 'Create modern homepage design', 1, 'high', 'in-progress', '2024-02-15 23:59:59', 8.0, 1),
('Implement Authentication', 'User login and registration system', 1, 'high', 'todo', '2024-02-20 23:59:59', 16.0, 1),
('Setup Database', 'Configure MySQL database schema', 1, 'high', 'done', '2024-01-10 23:59:59', 4.0, 1),
('API Endpoints', 'Create RESTful API endpoints', 1, 'medium', 'in-progress', '2024-02-25 23:59:59', 24.0, 1),
('Mobile UI Design', 'Design mobile app interface', 2, 'high', 'todo', '2024-03-15 23:59:59', 12.0, 2),
('Payment Integration', 'Integrate Stripe payment gateway', 3, 'urgent', 'planning', '2024-04-30 23:59:59', 20.0, 2);

-- Insert task assignees
INSERT INTO task_assignees (task_id, user_id) VALUES
(1, 3),
(1, 4),
(2, 3),
(3, 5),
(4, 5),
(5, 4);

-- Insert task dependencies
INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES
(2, 3),
(4, 3);

-- Insert comments
INSERT INTO comments (content, task_id, project_id, user_id) VALUES
('Great progress on the design!', 1, NULL, 2),
('We need to discuss the color scheme', 1, NULL, 3),
('Database setup completed successfully', NULL, 1, 5),
('API documentation is ready', NULL, 1, 1);

-- Insert activities
INSERT INTO activities (project_id, user_id, type, description, related_id, related_type) VALUES
(1, 1, 'project_created', 'Project "Website Redesign" was created', 1, 'project'),
(1, 5, 'task_completed', 'Task "Setup Database" was completed', 3, 'task'),
(1, 3, 'task_created', 'Task "Design Homepage" was created', 1, 'task'),
(1, 2, 'comment_added', 'Comment added to task', 1, 'comment');

-- Insert notifications
INSERT INTO notifications (user_id, type, message, related_id, related_type) VALUES
(3, 'task_assigned', 'You have been assigned to a new task', 1, 'task'),
(4, 'comment', 'John Doe commented on a task', 1, 'task'),
(5, 'task_completed', 'A task you were assigned to has been completed', 3, 'task');

