const bcrypt = require('bcryptjs');
const mysql = require('mysql2');
require('dotenv').config();

const connection = mysql.createConnection({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'taskflow_db',
  port: process.env.DB_PORT || 3306
});

const seedWithHashedPasswords = async () => {
  try {
    const password = 'password123';
    const hash = await bcrypt.hash(password, 10);
    
    console.log('Generated password hash:', hash);
    
    // Insert users with properly hashed passwords
    const users = [
      ['admin@taskflow.com', hash, 'Admin User', 'admin', 'active'],
      ['manager@taskflow.com', hash, 'Manager User', 'manager', 'active'],
      ['john@taskflow.com', hash, 'John Doe', 'member', 'active'],
      ['jane@taskflow.com', hash, 'Jane Smith', 'member', 'active'],
      ['bob@taskflow.com', hash, 'Bob Johnson', 'member', 'active']
    ];

    // Clear existing users
    await connection.promise().execute('DELETE FROM users WHERE email LIKE ?', ['%@taskflow.com']);
    
    // Insert users
    for (const user of users) {
      await connection.promise().execute(
        'INSERT INTO users (email, password, name, role, status) VALUES (?, ?, ?, ?, ?)',
        user
      );
    }
    
    console.log('Users inserted with hashed passwords');
    
    // Now run the rest of the seed data
    const fs = require('fs');
    const seedPath = require('path').join(__dirname, 'seedData.sql');
    const seed = fs.readFileSync(seedPath, 'utf8');
    
    // Remove user insert from seed file content
    const seedWithoutUsers = seed.split('-- Insert sample users')[1];
    
    connection.query(seedWithoutUsers, (err) => {
      if (err) {
        console.error('Error inserting seed data:', err);
        connection.end();
        process.exit(1);
      }
      console.log('Seed data inserted successfully!');
      connection.end();
      process.exit(0);
    });
  } catch (error) {
    console.error('Error:', error);
    connection.end();
    process.exit(1);
  }
};

seedWithHashedPasswords();



