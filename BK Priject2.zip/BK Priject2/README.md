# TaskFlow - Collaborative Project Management API

A powerful RESTful API for a collaborative project management platform that enables teams to create projects, manage tasks, track progress, and facilitate team communication.

## ⚠️ INSTALLATION REQUIRED FIRST!

**If you get "npm: command not found" error, you MUST install Node.js first!**

👉 **Quick Fix:** See `README_INSTALL.md` or `INSTALL_NOW.md` for step-by-step instructions.

👉 **Or run:** Double-click `install_nodejs.ps1` to get help installing Node.js.

**You cannot run `npm install` until Node.js is installed on your computer!**

## 🚀 Features

### Core Functionalities

1. **Project & Team Management**
   - Multi-level project creation with hierarchies
   - Team formation with role assignments
   - Project timeline and milestone tracking
   - Resource allocation and capacity planning

2. **Task Management System**
   - Task creation with priority levels and categories
   - Task assignment with multiple assignees support
   - Dependency management between tasks
   - Status tracking with custom workflow states

3. **Collaboration Features**
   - Comment system with threaded discussions
   - File attachment and document sharing
   - Activity feed with project timeline
   - Notification system for updates and mentions

4. **Analytics & Reporting**
   - Project progress tracking with visual indicators
   - Team productivity metrics and burndown charts
   - Time tracking and effort estimation
   - Custom report generation with filters

5. **Real-time Features**
   - WebSocket integration for live updates
   - Real-time notifications
   - Live activity feeds

## 📋 Prerequisites

- Node.js (v14 or higher)
- MySQL (v5.7 or higher)
- npm or yarn

## 🛠️ Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd taskflow-api
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env
   ```
   
   Edit `.env` file with your database credentials:
   ```env
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=your_password
   DB_NAME=taskflow_db
   DB_PORT=3306
   JWT_SECRET=your-super-secret-jwt-key
   ```

4. **Set up the database**
   ```bash
   npm run migrate
   ```

5. **Start the server**
   ```bash
   npm start
   ```
   
   For development with auto-reload:
   ```bash
   npm run dev
   ```

The API will be available at `http://localhost:3000`

## 📚 API Documentation

### Base URL
```
http://localhost:3000/api/v1
```

### Authentication

Most endpoints require authentication. Include the JWT token in the Authorization header:
```
Authorization: Bearer <your-token>
```

### Endpoints

#### Authentication
- `POST /auth/register` - Register a new user
- `POST /auth/login` - Login user
- `GET /auth/me` - Get current user

#### Projects
- `GET /projects` - Get all projects (with pagination and filters)
- `GET /projects/:id` - Get project by ID
- `POST /projects` - Create a new project
- `PUT /projects/:id` - Update project
- `DELETE /projects/:id` - Delete project (admin/manager only)
- `GET /projects/:id/hierarchy` - Get project hierarchy

#### Tasks
- `GET /tasks` - Get all tasks (with filters)
- `GET /tasks/:id` - Get task by ID
- `POST /tasks` - Create a new task
- `PUT /tasks/:id` - Update task
- `DELETE /tasks/:id` - Delete task
- `POST /tasks/:id/assignees` - Assign user to task
- `DELETE /tasks/:id/assignees/:userId` - Remove assignee
- `POST /tasks/:id/dependencies` - Add task dependency
- `DELETE /tasks/:id/dependencies/:dependsOnId` - Remove dependency

#### Teams
- `GET /teams` - Get all teams
- `GET /teams/:id` - Get team by ID
- `POST /teams` - Create a new team
- `POST /teams/:id/members` - Add member to team
- `DELETE /teams/:id/members/:userId` - Remove member from team

#### Comments
- `GET /comments` - Get comments (requires task_id or project_id)
- `POST /comments` - Create a comment
- `PUT /comments/:id` - Update comment
- `DELETE /comments/:id` - Delete comment

#### Files
- `POST /files/upload` - Upload a file
- `GET /files` - Get files (with filters)
- `GET /files/:id/download` - Download file
- `DELETE /files/:id` - Delete file

#### Activities
- `GET /activities` - Get activity feed

#### Notifications
- `GET /notifications` - Get user notifications
- `PUT /notifications/:id/read` - Mark notification as read
- `PUT /notifications/read-all` - Mark all notifications as read

#### Analytics
- `GET /analytics/projects/:id/progress` - Get project progress
- `GET /analytics/teams/:id/productivity` - Get team productivity metrics
- `GET /analytics/projects/:id/burndown` - Get burndown chart data
- `GET /analytics/reports` - Generate custom reports

### Request/Response Format

All responses follow this format:
```json
{
  "success": true,
  "message": "Success message",
  "data": {
    // Response data
  }
}
```

Error responses:
```json
{
  "success": false,
  "message": "Error message"
}
```

### Pagination

Endpoints that support pagination accept query parameters:
- `page` - Page number (default: 1)
- `limit` - Items per page (default: 10, max: 100)

Response includes pagination metadata:
```json
{
  "meta": {
    "currentPage": 1,
    "totalPages": 5,
    "totalItems": 50,
    "itemsPerPage": 10,
    "hasNextPage": true,
    "hasPreviousPage": false
  }
}
```

## 🗄️ Database Schema

The database follows 3NF normalization with the following main entities:

- **users** - User accounts and authentication
- **projects** - Projects with hierarchical support (parent_id)
- **teams** - Teams associated with projects
- **team_members** - Many-to-many relationship between teams and users
- **tasks** - Tasks with status, priority, and assignments
- **task_assignees** - Many-to-many relationship between tasks and users
- **task_dependencies** - Task dependency relationships
- **comments** - Comments on tasks/projects with threading support
- **files** - File attachments
- **activities** - Activity feed entries
- **notifications** - User notifications

See `migrations/schema.sql` for complete schema definition.

## 🧪 Testing

Run tests:
```bash
npm test
```

Run tests with coverage:
```bash
npm test -- --coverage
```

The project maintains a minimum of 70% test coverage.

## 🔒 Security Features

- JWT-based authentication
- Password hashing with bcrypt
- Input validation with express-validator
- SQL injection prevention (parameterized queries)
- CORS configuration
- Rate limiting
- Helmet.js for security headers
- File upload size limits

## 📡 WebSocket API

The API includes WebSocket support for real-time updates:

```javascript
const socket = io('http://localhost:3000');

// Authenticate
socket.emit('authenticate', token);

// Join project room
socket.emit('join-project', projectId);

// Listen for updates
socket.on('project-update', (data) => {
  console.log('Project updated:', data);
});
```

## 📁 Project Structure

```
taskflow-api/
├── config/           # Configuration files
│   ├── database.js   # Database connection
│   └── logger.js     # Winston logger setup
├── middleware/       # Express middleware
│   ├── auth.js       # Authentication middleware
│   ├── errorHandler.js
│   ├── rateLimiter.js
│   └── validator.js
├── models/          # Data models
│   ├── User.js
│   ├── Project.js
│   ├── Task.js
│   ├── Activity.js
│   └── Notification.js
├── routes/          # API routes
│   ├── auth.js
│   ├── projects.js
│   ├── tasks.js
│   ├── teams.js
│   ├── comments.js
│   ├── files.js
│   ├── activities.js
│   ├── notifications.js
│   └── analytics.js
├── utils/           # Utility functions
│   ├── pagination.js
│   └── response.js
├── websocket/       # WebSocket handlers
│   └── socketHandler.js
├── migrations/      # Database migrations
│   ├── schema.sql
│   ├── seedData.sql
│   ├── runMigrations.js
│   └── seedData.js
├── tests/           # Test files
│   ├── auth.test.js
│   └── projects.test.js
├── uploads/         # File uploads directory
├── logs/            # Log files
├── server.js        # Main server file
├── package.json
└── README.md
```

## 🚦 API Versioning

The API uses versioning in the URL path (`/api/v1/`). Future versions will be added as `/api/v2/`, etc.

## 📝 Sample Data

The database includes sample data for testing:
- 5 sample users (admin, manager, and 3 members)
- 3 sample projects with 2 sub-projects
- 3 teams with members
- 6 sample tasks with assignments and dependencies
- Sample comments, activities, and notifications

Default password for all sample users: `password123`

## 🔧 Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| PORT | Server port | 3000 |
| DB_HOST | Database host | localhost |
| DB_USER | Database user | root |
| DB_PASSWORD | Database password | - |
| DB_NAME | Database name | taskflow_db |
| DB_PORT | Database port | 3306 |
| JWT_SECRET | JWT secret key | - |
| JWT_EXPIRE | JWT expiration | 7d |
| UPLOAD_DIR | File upload directory | ./uploads |
| MAX_FILE_SIZE | Max file size in bytes | 10485760 |

## 📄 License

MIT

## 👥 Contributing

1. Create a feature branch
2. Make your changes
3. Write/update tests
4. Ensure tests pass and coverage is maintained
5. Submit a pull request

## 🐛 Troubleshooting

**Database connection errors:**
- Verify MySQL is running
- Check database credentials in `.env`
- Ensure database exists or run migrations

**Port already in use:**
- Change PORT in `.env`
- Kill the process using the port

**File upload errors:**
- Ensure `uploads/` directory exists and is writable
- Check file size limits

## 📞 Support

For issues and questions, please open an issue on the repository.

