# PowerShell script to help install Node.js
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Node.js Installation Helper" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Check if Node.js is already installed
$nodeInstalled = Get-Command node -ErrorAction SilentlyContinue
$npmInstalled = Get-Command npm -ErrorAction SilentlyContinue

if ($nodeInstalled -and $npmInstalled) {
    Write-Host "[SUCCESS] Node.js is already installed!" -ForegroundColor Green
    Write-Host "Node version: " -NoNewline
    node --version
    Write-Host "npm version: " -NoNewline
    npm --version
    Write-Host ""
    Write-Host "You can now run: npm install" -ForegroundColor Green
    pause
    exit 0
}

Write-Host "[INFO] Node.js is NOT installed on your system." -ForegroundColor Yellow
Write-Host ""

# Check for Chocolatey
$chocoInstalled = Get-Command choco -ErrorAction SilentlyContinue

if ($chocoInstalled) {
    Write-Host "[OPTION 1] Chocolatey detected!" -ForegroundColor Cyan
    Write-Host "You can install Node.js using Chocolatey:" -ForegroundColor White
    Write-Host "  Run PowerShell as Administrator and execute:" -ForegroundColor White
    Write-Host "  choco install nodejs" -ForegroundColor Yellow
    Write-Host ""
}

# Check for Winget
$wingetInstalled = Get-Command winget -ErrorAction SilentlyContinue

if ($wingetInstalled) {
    Write-Host "[OPTION 2] Winget detected!" -ForegroundColor Cyan
    Write-Host "You can install Node.js using Winget:" -ForegroundColor White
    Write-Host "  winget install OpenJS.NodeJS.LTS" -ForegroundColor Yellow
    Write-Host ""
}

Write-Host "[OPTION 3] Manual Installation (Recommended)" -ForegroundColor Cyan
Write-Host ""
Write-Host "1. Open your web browser" -ForegroundColor White
Write-Host "2. Go to: https://nodejs.org/" -ForegroundColor Yellow
Write-Host "3. Download the LTS version (left green button)" -ForegroundColor White
Write-Host "4. Run the installer (.msi file)" -ForegroundColor White
Write-Host "5. Make sure 'Add to PATH' is checked" -ForegroundColor White
Write-Host "6. Complete the installation" -ForegroundColor White
Write-Host "7. RESTART your terminal" -ForegroundColor Red
Write-Host "8. Run this script again to verify" -ForegroundColor White
Write-Host ""

# Try to open browser
$response = Read-Host "Would you like to open the Node.js download page? (Y/N)"
if ($response -eq 'Y' -or $response -eq 'y') {
    Start-Process "https://nodejs.org/"
    Write-Host ""
    Write-Host "Browser opened! Download the LTS version and install it." -ForegroundColor Green
    Write-Host "After installation, close this window and open a NEW terminal." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")



