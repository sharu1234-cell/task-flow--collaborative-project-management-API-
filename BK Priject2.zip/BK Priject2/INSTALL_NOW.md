# ⚠️ IMPORTANT: Install Node.js First!

## You MUST install Node.js before running npm install

The error "command not found" means Node.js is NOT installed on your computer.

---

## 🚀 EASIEST WAY - Follow These Steps:

### Step 1: Download Node.js
1. Open your web browser
2. Go to: **https://nodejs.org/**
3. You'll see two green buttons - click the **LEFT one** (LTS - Recommended)
4. It will download a file like: `node-v20.x.x-x64.msi`

### Step 2: Install Node.js
1. Find the downloaded file (usually in Downloads folder)
2. **Double-click** the `.msi` file
3. Click **"Next"** through all the screens
4. **IMPORTANT:** Make sure "Add to PATH" is checked (it usually is by default)
5. Click **"Install"**
6. Wait for installation to complete
7. Click **"Finish"**

### Step 3: Restart Your Terminal
1. **CLOSE** your current terminal/PowerShell window completely
2. Open a **NEW** terminal/PowerShell window
3. Navigate to your project folder:
   ```
   cd "C:\Users\SHARVANI\BK Priject2"
   ```

### Step 4: Verify Installation
Type these commands one by one:
```
node --version
npm --version
```

**If you see version numbers** (like v20.10.0 and 10.2.3), you're ready!

### Step 5: Install Project Dependencies
Now run:
```
npm install
```

---

## 🔄 Alternative: Use Chocolatey (If You Have It)

If you have Chocolatey package manager installed:

Open PowerShell as Administrator and run:
```powershell
choco install nodejs
```

---

## 🔄 Alternative: Use Winget (Windows 11)

Open PowerShell and run:
```powershell
winget install OpenJS.NodeJS.LTS
```

---

## ❓ Still Not Working?

1. **Restart your computer** after installing Node.js
2. Make sure you're using a **NEW** terminal window
3. Check if Node.js appears in Start Menu (search for "Node.js")
4. Try running from Node.js Command Prompt (if available in Start Menu)

---

## 📞 Need Help?

If you're still stuck:
1. Take a screenshot of the error
2. Check if Node.js appears in: `C:\Program Files\nodejs\`
3. Try running: `C:\Program Files\nodejs\npm.cmd install`

---

**Remember: You CANNOT run npm install until Node.js is installed!**



